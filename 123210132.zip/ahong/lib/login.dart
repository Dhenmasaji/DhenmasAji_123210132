import 'package:ahong/header.dart';
import 'package:flutter/material.dart';
import 'inputWrap.dart';


class Login extends StatelessWidget {
  const Login({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, colors: [
            Color.fromRGBO(124, 101, 169, 1),
            Color.fromRGBO(150, 212, 202, 1),
          ]),
        ),
      child: Column(
        children: <Widget>[
          SizedBox(height: 80,),
          Header(),
          Expanded(child: Container(
            decoration : BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(60),
                topRight: Radius.circular(60),
              )
            ),
                child:InputWrap(),
          ))
        ],
      ),
      ),
    );

  }
}