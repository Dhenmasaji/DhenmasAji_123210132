import 'package:flutter/material.dart';
import 'inputWrap.dart';

class Button extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Container(
      height: 50,
      margin: EdgeInsets.symmetric(horizontal: 0),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Text("LOGIN" , style: TextStyle(
          color: Colors.white,
          fontSize: 15,
          fontWeight: FontWeight.bold
        ),),
      ),
    );
  }
}