package com.example.ahong

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
